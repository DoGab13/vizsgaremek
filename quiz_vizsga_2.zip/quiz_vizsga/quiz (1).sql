-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Ápr 26. 16:32
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `quiz`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `questions`
--

CREATE TABLE `questions` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `imagePath` varchar(30) NOT NULL,
  `answer1` varchar(30) NOT NULL,
  `answer2` varchar(30) NOT NULL,
  `answer3` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_hungarian_ci;

--
-- A tábla adatainak kiíratása `questions`
--

INSERT INTO `questions` (`id`, `name`, `imagePath`, `answer1`, `answer2`, `answer3`) VALUES
(1, 'piramis', '/src/img/1.jpg', 'A gízai piramisok', 'Alexandriai világítótorony', 'Hamurapi sziklatemploma'),
(2, 'A Magyar Parlament', '/src/img/3.jpg', 'A Magyar Parlament', 'Alexandriai világítótorony', 'Nápolyi kőszínházak'),
(3, 'moai', '/src/img/moai.jpg', 'Húsvét-Szigetek, Moai szobor c', 'Sechell szigetek, törzsi szobr', 'Arámiai ősszobrok'),
(4, 'colosseum', '/src/img/colosseum.jpg', 'Colosseum, Róma', 'Achropolis Athén', 'Nápolyi kőszínházak'),
(5, 'bison', '/src/img/bison.jpg', 'Bison barlang, Altamira', 'Neandervölgyi barlangrajz', 'Bivaly fresko, Nápoly'),
(6, 'Stonhenge', '/src/img/stonehenge.jpg', 'Stonehenge, Anglia', 'Törzsi kőszobrok, Seychelles s', 'Közép-Afrika, templom romok'),
(7, 'Adam', '/src/img/adam.jpg', 'Ádám Teremtése, Sixtus-kápolna', 'Apa és Fia, Leonardo de Vinci', 'Érintés, ismeretlen művész'),
(8, 'Lánchíd', '/src/img/lanchid.jpg', 'Széchényi Lánchíd, Budapest', 'Qubaro-ma híd, Botswana', 'London, Temse híd'),
(9, 'Saint Basil', '/src/img/saintbasil.jpg', 'Boldog Vazul-székesegyház', 'Gaudi Színes katedrális', 'Téli palota, Szentpétervár'),
(10, 'Taj Mahal', '/src/img/2.jpg', 'Taj Mahal', 'Alexandriai világítótorony', 'Hamurapi sziklatemploma'),
(11, 'Bláthy', '/src/img/blathy.jpg', 'Blathy Suli', 'Alexandriai világítótorony', 'Hamurapi sziklatemploma'),
(12, 'moai', '/src/img/moai.jpg', 'Húsvét-Szigetek, Moai szobor c', 'Sechell szigetek, törzsi szobr', 'Arámiai ősszobrok'),
(13, 'moai', '/src/img/moai.jpg', 'Húsvét-Szigetek, Moai szobor c', 'Sechell szigetek, törzsi szobr', 'Arámiai ősszobrok'),
(14, 'colosseum', '/src/img/colosseum.jpg', 'Colosseum, Róma', 'Achropolis Athén', 'Nápolyi kőszínházak'),
(16, 'agamemnon', '/src/img/agamemnon.jpg', 'Agamemnon halotti maszkja', 'Homérosz arcmása', 'Penelopé halotti maszkja'),
(17, 'antonioVivaldi', '/src/img/antonioVivaldi.jpg', 'Antonio Vivaldi', 'Bach', 'Leonardo da Vinci'),
(18, 'arcDeTriomphe', '/src/img/arcDeTriomphe.jpg', 'Arc de Triomphe', 'váci Diadalív', 'Stonehenge'),
(19, 'babitsMihaly', '/src/img/babitsMihaly.jpg', 'Babits Mihály', 'Ernest Hemingway', 'Liszt Ferenc'),
(20, 'caravaggioSirbatetel', '/src/img/caravaggioSirbatetel.', 'Caravaggio: Sírbatétel', 'Munkácsy: Sírbatétel', 'ismeretlen'),
(21, 'casaBatllo', '/src/img/casaBatllo.jpg', 'Casa Batllo', 'piramis', 'templom'),
(22, 'csodaszarvass', '/src/img/csodaszarvas.jpg', 'Csodaszarvas', 'Kelta bross', 'egyiptomi falidísz'),
(23, 'ernestHemingway', '/src/img/ernestHemingway.jpg', 'Ernest Hemingway', 'Marcus T. Cicero', 'Frank L. Wright'),
(24, 'faberge', '/src/img/faberge.jpg', 'Faberge tojások', 'Húsvéti tojásokok', 'Nyúl tojások'),
(25, 'lisztFerenc', '/src/img/lisztFerenc.jpg', 'Liszt Ferenc', 'Havasi Balázs', 'egy pankrátor'),
(26, 'maganyosC', '/src/img/maganyosC.jpg', 'Magányos cédrus', 'Ez egy fa', 'Páva'),
(27, 'matyasKulacs', '/src/img/matyasKulacs.jpg', 'Mátyás kulacs', 'Sör tartó', 'Mandala'),
(28, 'niccoloP', '/src/img/niccoloP.jpg', 'Niccoló Paganini', 'Mátyás király', 'Janus Pannonius'),
(29, 'panteon', '/src/img/panteon.jpg', 'Panteon', 'Egy lyukas tető', 'Tésztaszűrő'),
(31, 'moaieee', '/src/img/moai.jpg', 'Húsvét-Szigetek, Moai szobor c', 'Sechell szigetek, törzsi szobr', 'Arámiai ősszobrok'),
(50, 'globeSzinhaz', '/src/img/globeSzinhaz.jpg', 'Globe Színház', 'Teve karám', 'Bajor templom'),
(51, 'johannSebastianBach', '/src/img/johannSebastianBach.j', 'Johann S. Bach', 'VII.Henrich herceg', 'Casanova'),
(53, 'kolcsey', '/src/img/kolcsey.jpg', 'Kölcsey Ferenc', 'Dr. House', 'Ady Endre'),
(54, 'leanyGyF', '/src/img/leanyGyF.jpg', 'leány gyöngy fülbevalóval', 'Mária', 'Magdolna'),
(55, 'pontDuGard', '/src/img/pontDuGard.jpg', 'Pont du Gard', 'Egy híd', 'Istár kapu'),
(56, 'pyotrllyichT', '/src/img/pyotrllyichT.jpg', 'Pyotrllyich Tchaikovsky', 'Petőfi Sándor', 'Kiss Ernő'),
(57, 'radnotiMiklos', '/src/img/radnotiMiklos.jpg', 'Radnóti Miklós', 'Széchenyi István', 'Munkácsy Mihály'),
(58, 'romolusRemus', '/src/img/romolusRemus.jpg', 'Romolus és Remus', 'Maugli', 'Tarzan'),
(59, 'willendorfiV', '/src/img/willendorfiV.jpg', 'Willendorfi Vénusz', 'Svájci Mars', 'Holland Pluto');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `scores`
--

CREATE TABLE `scores` (
  `id` int(10) NOT NULL,
  `score` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_hungarian_ci;

--
-- A tábla adatainak kiíratása `scores`
--

INSERT INTO `scores` (`id`, `score`, `name`, `date`) VALUES
(15, 16, 'Név nélkül', '2024-04-18 17:59:55'),
(18, 6, 'Csacska', '2024-04-18 18:03:57'),
(30, 2, 'Név nélkül', '2024-04-18 19:00:52'),
(42, 2, 'Csacska', '2024-04-19 09:24:26'),
(43, 2, 'Csacska', '2024-04-19 09:38:19'),
(44, 2, 'Név nélkül', '2024-04-19 10:12:32'),
(45, 2, 'Név nélkül', '2024-04-19 10:29:30'),
(46, 2, 'Név nélkül', '2024-04-19 13:42:34'),
(47, 15, 'Név nélkül', '2024-04-19 13:43:46'),
(48, 2, 'Név nélkül', '2024-04-22 13:05:21'),
(49, 12, 'Név nélkül', '2024-04-25 09:22:52'),
(50, 12, 'Név nélkül', '2024-04-25 09:29:32'),
(51, 25, 'Név nélkül', '2024-04-26 08:25:35'),
(52, 29, 'Név nélkül', '2024-04-26 08:42:38'),
(53, 38, 'Név nélkül', '2024-04-26 09:00:42');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_hungarian_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(20, 'Kalapácska', 'kalap@abaaaaba.com', '$2b$08$Z9Xu.sld4I.WDA0/FXHzjOYUSt3RPUAGyScaI6hcQytnWRMSVNMDC'),
(21, 'Kalapácska', 'kalap@abaaadddaba.com', '$2b$08$k6cwhbTrDt417Dpv7lvYiOhRMQ.8lU1aMQEwVzs6QozevJ5Mab0W2'),
(22, 'Kakaómatyika', 'kakao@matyika.hu', '$2b$08$zC3blQSzZo0Zk0x6icrZDOYX2y816THwklLLyfbcBK4Pa8eED0c02'),
(23, 'Cica', 'cica@kutyus.com', '$2b$08$11eIRcqYKPRhwxnxYtT9guZn/tiuefDaPNuAFYyaQ.rW1O/KkEH6G'),
(27, 'Csacska', 'csacsi@csacsi.hu', '$2b$08$eTocUXJBU6Av5htx2aE3zebsp8/xzKVaoIPsonnr0FV.zbDoCSpVy'),
(28, 'Cica', 'cicaeskutya@gal.hu', '$2b$08$VSyOd4JuepXj4.u0hytz2OLFrY5WryWDrqZN9apUYWEQXqsPWzcfO'),
(29, 'kifli', 'zsemle123@kenyer.com', '$2b$08$YqY76rNmTAetgZ4hIbzV2ObLAa.urtUCR1auvXaw7ID6kJFAgykyC');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `scores`
--
ALTER TABLE `scores`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT a táblához `scores`
--
ALTER TABLE `scores`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

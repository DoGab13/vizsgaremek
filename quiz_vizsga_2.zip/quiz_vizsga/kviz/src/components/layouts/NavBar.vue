<script>
import { RouterLink, useRouter} from "vue-router";

export default {

    data() {
      return {
        toggleValue: true,
        
            };
        },
        methods: {
      
        onTest(){
             alert('Alert Test')
        },
        
    }
}
</script>

<template>

<nav class="navbar navbar-expand-lg mt-10">
  <div class="container-fluid justify-content-center">
            
  <router-link to="/" class="nav-link text-dark">Kezdőlap</router-link>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarScroll">
        <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
          <li class="nav-item">
            <router-link to="/cards" class="nav-link"  href="#" >Kártyák</router-link> 
          </li>
          <li class="nav-item">
            <router-link to="/interestingFacts" class="nav-link">Érdekességek</router-link>
          </li>
          <li class="nav-item">
            <router-link to="/prizes" class="nav-link">Nyeremények</router-link>
          </li>
          <li class="nav-item">
            <router-link to="/game" class="nav-link"  href="#" >Játék</router-link> 
          </li> 
          <li class="nav-item">
            <router-link to="/database" class="nav-link"  href="#" >Adatbázis</router-link> 
          </li>
        </ul>
      
        <form class="d-flex gap-3" role="search">   
          <router-link to="/login"><button class="btn btn-warning" router-link to="/login" href="#" >Bejelentkezés</button></router-link>
          <router-link to="/register"><button class="btn btn-info">Regisztráció</button></router-link>
        </form>
        </div>
      </div>
    </nav>
   
</template>

<style scoped>
.nav-link {
  font-size: larger;
}
.navbar{
  background-color: #f5c0c8;
}
</style>
<template>
  <footer>
    <p>Elérhetőségek:</p>
    <p>email@mail.com +38 40/111-2222</p>
  </footer>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style scoped>
footer {  
  width: 100%;
  background-color: #f8d1d7 ;
  padding: 10px;
  text-align: center;
}
</style>
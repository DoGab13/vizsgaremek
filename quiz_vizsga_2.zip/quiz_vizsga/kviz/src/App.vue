<script setup>
import { RouterView } from 'vue-router'
import NavBar from "@/components/layouts/NavBar.vue";
import Footer from "@/components/footer/Footer.vue"; 

</script>

<template>
<div>
 <nav-bar/>
 <RouterView />
 <Footer/>
</div> 
</template>

<style>
</style>

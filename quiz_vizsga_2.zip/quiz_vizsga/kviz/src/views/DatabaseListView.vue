<template>
    <div>
      <br>
      <h5>Jelenleg az adatbázis egy mySQL szervereren fut (XAMP), amit egy Node.js szerver szolgál ki a Vue.js felé.
        Próbálkoztunk json fájlokkal is, amiben három tömb található, amit egy node.js szerver szolgáltat.
        </h5>
    <br>
      <div class="container-fluid">
        <h5>Felhasználók tábla</h5>
      <table class="table table-striped mt-2">
        <thead class="pt-4 bg-warning text-center">
    
          <th >Id</th>
      <th>Név</th>
      <th>Email</th>
      <th>Dátum</th>
      <th >Művelet</th>
    </thead>
<tbody class="text-center" v-for="user in users" :key="user.id"> <tr><td>{{ user.id }} </td> <td>{{user.name }}</td> <td>{{ user.email }} </td> <td>{{user.date }}</td>
  <td><button class="btn btn-info" @click="">Módosítás</button><button class="btn btn-danger" @click="deleteUser(user.id)">Törlés</button></td></tr>
</tbody>
</table>
</div>

<br>
<div class="container-fluid">
        <h5>Eredmények tábla</h5>
      <table class="table table-striped mt-2">
        <thead class="pt-4 bg-warning text-center">
        <th >Id</th>
      <th>UserId</th>
      <th>Pontszám</th>
      
    </thead>
<tbody class="text-center" v-for="item in scores" :key="item.id"><tr><td>{{ item.id }} </td> <td>{{ item.name }}</td> <td>{{ item.score }} </td> 
</tr>
</tbody>
</table>
</div>
<br>
<h5>Kérdések tábla</h5>
<div class="container-fluid">
<table class="table table-striped mt-2">
  <thead class="pt-4 bg-warning text-center">
    <th>id</th><th>Név</th><th>elérési út</th><th>válasz 1</th><th>válasz 2</th><th>válasz 3</th><th >Művelet</th>
  </thead>
<tbody class="text-center" v-for="item in questions" :key="item.id" > <tr> 
<th>{{ item.id }}</th>
<th>{{ item.name }}</th>
<th>{{item.imagePath}}</th>
<th>{{item.answer1}}</th>
<th>{{item.answer2}}</th>
<th>{{item.answer3}}</th>
<th><button class="btn btn-info" data-bs-toggle="modal" :data-bs-target="`#modal-${item.id}` ">Módosítás</button>
  <button class="btn btn-danger" @click="deleteQuestion(item.id)">Törlés</button></th>
  
</tr>
<EditModal :id="`modal-${item.id}`" :item="item" @modify-question="modifyQuestion"/> 

</tbody>

<tr>
  <td>#</td>
  <td><input type="text" class="form-control" name="name" id="name" v-model="newQuestion.name"></td>
  <td><input type="text" class="form-control" name="category" id="category" v-model="newQuestion.answer1"></td>
  <td><input type="text" class="form-control" name="description" id="description" v-model="newQuestion.answer2"></td>
  <td><input type="text" class="form-control" name="price" id="price" v-model="newQuestion.answer3"></td>
  <td><input type="text" class="form-control" name="rating" id="rating" v-model="newQuestion.imagePath"></td>
  
  <td colspan="2">
    <button class="btn btn-primary" @click="createQuestion(this.newQuestion)">Felvétel</button>
  </td>
</tr>
</table>

</div>

      
      <!-- <ul>
        <li v-for="question in questions" :key="question.id" > {{ question.id }} {{ question.name }}</li>
      </ul> -->
    </div>

  </template>
  
  <script>
  import { http } from '@/components/utils/http';
  import EditModal from "@/components/layouts/EditModal.vue";
  
  
  export default {
    
    
    components: {
      EditModal
    },

    data() {
      return {
        users: [],
        scores: [],
        questions: [],
        item: Object,
        newQuestion: {          
          name: "",
          imagePath: "",
          answer1: "",
          answer2: "",
          answer3: ""
        }
     };
    },
    methods:{
    async getUsers(){
      const response = await http.get('users')
      this.users=await response.data;
    },
    async getScores(){
      const  response = await http.get('scores')
      this.scores=await response.data;
    },
    async getQuestions(){
      const response = await http.get('questions')
      this.questions=await response.data;
    },
    async createQuestion(newQuestion){
      const response= await http.post('questions',newQuestion)
      this.questions.push(response.data);
    },
    async modifyQuestion(modifiedQuestion){
       const response = await http.put(`questions/${modifiedQuestion.id}`,modifiedQuestion)
      const index = this.questions.findIndex(item=> item.id===modifiedQuestion.id);
      this.questions.splice(index,1,response.data);
    },
    async deleteQuestion(id){
      const response= await http.delete(`/questions/${id}`)
     return response.data
   
      /* const index = this.question.findIndex(user=> user.id===id);
      this.question.splice(index,1); */
    },
    async deleteUser(id){
      const response= await http.delete(`/users/${id}`)
      const index = this.users.findIndex(user=> user.id===id);
      this.users.splice(index,1);
    },
    },
    mounted() {
        this.getUsers();
        this.getScores();
        this.getQuestions()
     
    }
  };
  </script>
<template>
<div class="container">
    <br>
    <br>
    <div class="row">
    <div class="col-6 mt-5 ">
    <h3>
        Rövid történetünk

    </h3>
     <br>
    <h5>
        Mindhárman szoftverfejlesztést tanultunk az óbudai Bláthyban, és úgy döntöttünk csapatba állunk, és közösen alkotunk valami 
        számunkra(is) szórakoztatót, ami mellesleg a vizsgamunkánk is lesz.</h5>
     <br>   
        <h5>
        Tanáraink inspirációjára választottuk az alkalmazott technológiákat és megoldásokat, lelkesedésből talán még indokolatlanul is tólsok időt beleölve ebbe a projetceb,
        de mindhárman nagyon élveztük. <br>

        Eszter az ötleteket, a designt és a struktúrát hozta, Gábor kitalálta a felépítést, az adatbázist és a tesztelést végezte,  András pedig a működési logikát csinálta,
         és a componensek összeillesztését végezte.  <br>Mindhárman persze mindenben részt vettünk, és sokszor átfedések voltak a munkáinkban.
        
    </h5>
    <br>
    <h6>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur, accusantium ab maxime unde quam dicta in quis perferendis 
        dolores praesentium porro nihil non hic quos quas deserunt error ipsum reprehenderit.

    </h6>
    <h6>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Hic ab excepturi cumque quam suscipit modi provident 
        distinctio corrupti, eaque, omnis corporis nihil magnam. Itaque, ducimus reiciendis non impedit nemo porro.</h6>
</div><div class="col-6 mt-5 "><img src="../img/blathy.jpg" ><p class="text-center">BMSZC Bláthy Ottó Titusz Informatikai Technikum, Óbuda</p></div>

    </div>    </div>


</template>
<script>

</script>

<style scoped>


img {

    margin-top: 5rem;
    border-radius: 2rem;
	margin-bottom: 1rem;
    max-width: 600px;

}
</style>

<!-- const questions1 = ref([
    {
        "name": 'piramis',
        "picture": 'https://as1.ftcdn.net/v2/jpg/00/55/13/44/1000_F_55134478_i4Cab4ixCa6vjgE0jRf6x0KO3QlZ93ji.jpg',
        "answer": 'A gízai piramisok',
        "wAnswer1": "Alexandriai világítótorony",
        "wAnswer2": "Hamurapi sziklatemploma",
    },
    {
        "name": 'tajmahal',
        "picture": 'https://t3.ftcdn.net/jpg/01/04/28/48/240_F_104284800_jM7PNqAcJnMp0x3hXz31mojLIGc4v37V.jpg',
        "answer": 'Taj Mahal',
        "wAnswer1": "Alexandriai világítótorony",
        "wAnswer2": "Hamurapi sziklatemploma",    
    },    
    {
        "name": 'parlament',
       "picture": "https://t4.ftcdn.net/jpg/06/42/44/13/240_F_642441337_ivCHSzHPjcFy9ZKSqwwthbC3RAION9xU.jpg",
       "answer": 'A Magyar Parlament',
       "wAnswer1": "Alexandriai világítótorony",
        "wAnswer2": "Hamurapi sziklatemploma",
    },
    {
        "name": 'moai',
        "picture": 'https://t3.ftcdn.net/jpg/00/63/06/02/240_F_63060262_N3MdGRRfy3Tax6ODmS8WaToek0GUuOJ8.jpg',
        "answer": 'Húsvét-Szigetek, Moai szobor csoport',
        "wAnswer1": "Sechell szigetek, törzsi szobrok",
        "wAnswer2": "Arámiai ősszobrok",
    },
    {
        "name": 'colosseum',
        "picture": 'https://t3.ftcdn.net/jpg/02/27/88/36/240_F_227883696_tvfOO6syjvdRJYZls1FvCSgUqfVAcNXL.jpg',
        "answer": 'Colosseum, Róma',
        "wAnswer1": "Achropolis Athén",
        "wAnswer2": "Nápolyi kőszínházak ",
    },
    {
        "name": 'bison',
        "picture": 'https://t3.ftcdn.net/jpg/02/23/74/26/240_F_223742628_YjA2dqop46KOSrE8e0xSQGrLLXaQ8MNW.jpg',
        "answer": 'Bison barlang, Altamira',
        "wAnswer1": "Neandervölgyi barlangrajz",
        "wAnswer2": "Bivaly fresko, Nápoly",
    },
    {
        "name": 'stonehenge',
        "picture": 'https://t4.ftcdn.net/jpg/01/52/88/67/240_F_152886744_npumNaMSiCRIdc51TgTB507uuKrX12uf.jpg',
        "answer": 'Stonehenge, Anglia',
        "wAnswer1": "Törzsi kőszobrok, Seychelles szigetek ",
        "wAnswer2": "Közép-Afrika, templom romok ",
    },
    {
        "name": 'Chichen itza piramis',
        "picture": 'https://kep.cdn.indexvas.hu/1/0/1878/18784/187846/18784689_1161229_cf5089ccd5562e5ca8b732fd1ff2c749_wm.jpg',
        "answer": 'Chichen itza piramis',
        "wAnswer1": "Érintés, ismeretlen művész",
        "wAnswer2": "Apa és Fia, Leonardo de Vinci",
    },
    {
        "name": 'lanchid',
        "picture": "https://t3.ftcdn.net/jpg/00/58/17/08/240_F_58170876_5PPy2uKE15nzCCxgdYKa2hK5VenPbaKW.jpg",
        "answer": 'Széchényi Lánchíd, Budapest',
        "wAnswer1": "Qubaro-ma híd, Botswana",
        "wAnswer2": "London, Temse híd",
    },
    {
        "name": 'saintbasil',
        "picture": 'https://as1.ftcdn.net/v2/jpg/00/86/82/32/1000_F_86823269_P7t1XoxWVierzNwYQmmcPuSoMFspixAy.jpg',
        "answer": 'Boldog Vazul-székesegyház',
        "wAnswer1": "Gaudi Színes katedrális",
        "wAnswer2": "Téli palota, Szentpétervár",
    }
    ]) 


const newScore = ref({
  name: userStore.user.name,
  score: userScore.value,
  date: new Date()
});
const getQuestions = async () => {
  try {
    const response = await http.get('questions');
    return response.data;
    onGame.value = true
  } catch (error) {
    console.error('Error getting questions:', error);
    throw error; // dobunk egy hibát, hogy a hívó tudjon róla
  }
};

const createScore = async () => {
  try {
    const response = await http.post('scores',newScore.value);
    const responseData = response.data; // A válasz adatai
    alert( responseData); // Visszajelzés a felhasználónak
  } catch (error) {
    const responseData = response.data;
    console.error('Error during score:', error, responseData);
    alert('score lose'); // Hibaüzenet a felhasználónak
  }
};

onMounted(async () => {
  try {
    const questions = await getQuestions();
    onGame.value = true
    // Most tedd meg, amit akarsz a lekért kérdésekkel
  } catch (error) {
    // Kezeld a hibát, ha a kérdések lekérése nem sikerült
  }
});

-->
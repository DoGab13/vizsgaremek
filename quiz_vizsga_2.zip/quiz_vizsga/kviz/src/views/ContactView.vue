<script setup>

</script>

<template>

<h2>Kapcsolat</h2>

</template>
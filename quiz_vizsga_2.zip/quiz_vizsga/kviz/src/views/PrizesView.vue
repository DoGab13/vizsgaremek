<template>

<h2 class="m-2 mt-5 text-center">Hogyan és- mit nyerhetsz?</h2>
<br>
<div class="container m-10 mt-5">
<h4>E HAVI NYERTESEINK:</h4>
<table class="table table-light">
  <thead>
    <tr>
      <th>Helyezés</th>
      <th>Név</th>
      <th>Nyeremény</th>
      <th>Pontszám</th>
    </tr>
  </thead>
  <tbody v-for="score in scores" :key="score.id">
    <tr>
      <th>1</th>
      <td>{{score.name }}</td>
      <td>Egy hét, 3 párizsi múzeum látogatás</td>
      <td>{{ score.score }}</td>
    </tr>
    <tr>
      <th>2</th>
      <td>{{ score.name }}</td>
      <td>Bécsi Szépművészeti Múzeum (3nap)</td>
      <td>{{ score.score }}</td>
    </tr>
    <tr>
      <th>3</th>
      <td>{{ score.name }}</td>
      <td>Látogatás a Nemzeti Múzeumba</td>
      <td>{{ score.score }}</td>
    </tr>
  </tbody>
</table>
</div>
<br>
<hr>

<ol>
  <li>Elsősorban művészetörténeti ismeret szükséges a játékhoz, mely könnyen elsajátítható.</li>
  <li>Regisztrálj, majd jelentkezz be oldalunkon.</li>
  <li>Kattints a játék menüpontra.</li>
  <li>A megjelenő képek alatt 3 lehetséges választ találsz arra, hogy mit ábrázol a kép. Jelöld be a helyes választ.</li>
  <li>Érd el a lehető legtöbb pontot elsőként, hogy a nyeremények valamelyikét megszerezd.</li>
  <li>A világ különböző pontjain elhelyezkedő múzeumaiba  - helyezéstől függően - nyerhetsz utazást.</li>
</ol>

</template>

<script>
import axios from 'axios';
import {http} from '@/components/utils/http.js';

export default {
  data() {
    return {
      score: [] 
    };
  },
methods: {
  async getScores() {
    try {
      const response = await http.get('scores');
      this.scores = response.data;
      console.log(scores);
    } catch (error) {
      console.error('Hiba történt a pontszámok lekérése közben:', error);
    }
  }
  },
monted(){
  this.getScores();
}
};
</script>

<style scoped>


</style>
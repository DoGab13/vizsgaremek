<script setup>
import { ref, reactive } from 'vue'; // TODO Objektumra áttenni a reactive-ot. TODO a hibás jelszó kezeklését megvalósítani!!!
import { http } from '@/components/utils/http';
import { useUserStore } from '../stores/users.js'
import { RouterLink, useRouter} from "vue-router";
import router from '../router/index';
import { Field, Form, ErrorMessage } from 'vee-validate';
import * as yup from 'yup';

const userStore = useUserStore()

const loginStatus = ref('')

const schema = yup.object ({
  email: yup.string().required().email(),
  password: yup.string().required(),
  
});

const user = ref({
  email: '',
  password: ''
});

const loginUser = async () => {
  try {
    const response = await http.post('login', user.value);
    userStore.user = response.data
    router.push('/game')
    console.log('Login successful!', response.data);
    loginStatus.value = 'success';

  } catch (error) {
    loginStatus.value = 'error';
    console.error('Error during login:', error);
    alert('Login failed! Please check your credentials.'); 
  }
};

</script>

<template>
<div class="container">
    <div class="row">
      <div class="col-md-4 offset-md-4">
        <div class="card my-5">
          <Form class="card-body cardbody-color p-lg-5" @submit="loginUser" :validation-schema="schema">
            <div class="text-center">
              <h3>Bejelentkezés</h3>
              <img src="../img/questionm.jpg" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3"
                width="200px" alt="profile">
            </div>
            <div class="mb-3">
              <Field name="email" type="text" class="form-control" id="email" v-model="user.email" 
                placeholder="Email"/>
              <ErrorMessage name="email" as="div" class="alert alert-danger m-1"/>
            </div>
            <div class="mb-3">
              <Field name="password" type="password" class="form-control" id="password" v-model="user.password" placeholder="password"/>
              <ErrorMessage name="password" as="div" class="alert alert-danger m-1"/>
            </div>
            <div class="text-center"><button type="submit" class="btn btn-color px-5 mb-5 w-100">Bejelentkezés</button></div>
            <div  class="form-text text-center mb-5 text-dark">Nincs regisztrációd? 
              <router-link to="/register" class="text-dark fw-bold">Regisztrálj!</router-link>
            </div>
          </Form>
        </div>

      </div>
    </div>
  </div>
</template>

<style scoped>
.btn-color{
  background-color: #0e1c36;
  color: #fff;
}

.profile-image-pic{
  height: 100px;
  width: 100px;
  object-fit: cover;
}

.cardbody-color{
  background-color: #b1ceec; 
}

a{
  text-decoration: none;
}


</style> 

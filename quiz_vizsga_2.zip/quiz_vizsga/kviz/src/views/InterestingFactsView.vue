<template>
<div class="m-5">
    <img src="../img_2/leonardo.jpg" alt="Leonardi da Vinci egyik anatomiai képe" class="img">
    
    <h4>Leonardo da Vinci</h4>
<ul>
    <li>Leonardo tükörírással jegyezte le gondolatait, állítólag így akarta megakadályozni, hogy ellopják ötleteit.</li>
    <li>Egyik leghíresebb műve, az emberi testnek a művészetekre tett hatását és arányait összefoglaló Vitruvius-tanulmány ötletét a legújabb kutatások szerint a tudós plagizálta.</li>
    <li>A firenzei bírósági dokumentumok szerint a tudóst 1476-ban szodómiával vádolták, de a vádat végül ejtették. A hírek szerint Leonardónak egy férfi modellje miatt kellett majdnem bűnhődnie.</li>
    <li> 2021-ben a Human Evolution című lapban közölték a majdnem tíz évig tartó kutatás eredményeit, ami 21 generáción és 690 éven át követte és vezette le a polihisztor családfáját. A reneszánsz mesternek legalább 22 féltestvére volt, a vizsgálat az apai oldalról vezette le az öt családi ágat. A kutatás során megtalálták Da Vinci 14, ma is élő férfirokonát, akik között volt irodai alkalmazott és acélmunkás is.</li>
    <li>Nagyon érdekelte az emberi test felépítése és működése, korát megelőzve számos dologra rájött ezzel kapcsolatban. Sok más mellett Da Vincit a férfi nemiszerv működése is nagyon érdekelte, és alaposan tanulmányozta is boncolásai során. Ennek köszönhetően ő volt az első, aki rájött, hogy az addigi hiedelmekkel ellentétben, az erekció során a pénisz nem a „felfújó” levegő miatt nő és keményedik meg, hanem az oda áramló vértől.
    </li>
</ul>

<hr>
    <img src="../img_2/sagradafamilia.jpg" alt="Sagrada familia" class="img">
    <h4>Sagrada Familia</h4>
<ul>
    <li>Az első követ 1882. március 19-én tették le. A templom alapjai Francisco de Paula del Villar tervei alapján készültek, viszont kivitelezését 1883-tól, a modernizmus legnagyobb képvidelője, Antonio Gaudi vette át, aki gótikus és modernista jegyeket kombinálva a saját építészeti stílusa alapján alakította át az terveket, tehát a mai arculat neki köszönhető.</li>
    <li>Az építész 1926-ban,  egy tragikus villamosbalesetben hunyt el, sírja a bazilika alagsorában lévő kápolnában (la Virgen del Carmen) található. </li>
    <li>Építését 1882-ben kezdték el és a mai napig nem fejezték be. Becslések szerint Gaudi halálának 100. évfordulójára, 2026-ra készül el.</li>
    <li>2010. november 6-án XVI. Benedek pápa bazilikává szentelte.</li>
    <li>A homlokzat 12 db, több mint 100 m hosszú harangtornyaiból  eddig 8 készült el. Ezek a haragtornyok a 12 apostolt szimbolizálják.</li>
    <li>4 tornya reprezentálja az evangélistákat, 1 a Szűz Máriát (125m) a központi legmagasabb torony (170m) pedig Jézus Krisztus tiszteletére készül el 2026-ra</li>
</ul>

<br><br><hr>

   <img src="../img_2/altamira.jpg" alt="Altamira barlangrajz" class="img">
   <h4>Altamira barlang</h4>
<ul>
    <li>A barlangra egy helyi vadász figyelt fel 1868-ban, rögtön szólt is róla a barlang tulajdonosának, Marcelino de Sautuolának, aki viszont 8 évig magasról…szóval nem szentelt nagy figyelmet a felfedezésnek. 1876-ban mégis megnézte a barlangot, és unott vállrándítással nyugtázta, amit látott. Amikor aztán 2 évvelkésőbb Párizsban egy ásatáson járt, pont olyan faragott köveket mutattak neki, mint amik Altamirában is voltak: na ekkor esett le neki, hogy az ő barlangja nem átlagos.</li>
    <li>A barlangban talált tárgyak, valamint a falakon lévő rajzok elemzése alapján a szakértők arra jutottak, hogy Altamira legalább két különböző kultúrához tartozó ősembercsoportnak is otthont adott. A legújabb számítások szerint az első és az utolsó rajz elkészülte között minimum 10.000 év telt el, de vannak, akik szerint ez az intervallum akár 20.000 év is lehet.</li>
</ul>
<hr>

    <img src="../img_2/images.jpg" alt="guggenheim múzeum" class="img">
    <h4>A Szellem Temploma: a Guggenheim</h4>
<ul>
    <li>A Guggenheim 1959. október 21-én, fél évvel Frank Lloyd Wright halála után nyitotta meg a kapuit a nagyközönség előtt. Az épület (és a bent kiállított absztrakt művészet) már a kezdetektől fogva nagyon megosztó volt. Míg egy kritikus Amerika legszebb épületeként hivatkozott rá, addig egy másik azt mondta, hogy ez a szerkezet inkább egy Wright-emlékmű, mint egy múzeum</li>
    <li>Wright nagyjából 700 vázlatot és 6 különálló makettet készített. Ezekből elég jól kivehető, hogy nem pusztán épületet tervezett, hanem egy élő organizmust.</li>
    <li>Wright redetileg csak a felső szinthez írja a TF (terrazzo floor) jelzést, a látogatók számára nyitott terek burkolatát parafából képzelte. Ez az anyagleírás is utal arra, hogy Wright a múzeumot mint társadalmi teret képzelte el: a parafa elnyelte volna a hangot, ezáltal a rotunda teljesen más akusztikájú lenne. A tervet azért vetették el, mert a parafát nagyon nehéz lenne ápolni és karbantartani.</li>
</ul>

<hr>
</div>
</template>

<script>
  export default {
    data() {
      return {
       
      };
    }
  };
  
</script>
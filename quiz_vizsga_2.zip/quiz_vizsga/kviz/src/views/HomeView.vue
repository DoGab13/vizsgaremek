<template>
  <div class="container" id="app">
  
  <div class="row mt-5">
  <div class="col-6 mt-5 ">
      
      <h1>Igazán ismered a világunkat?</h1>
      <br>
      <h5><i class="glyphicon glyphicon-cloud" style="font-size:36px;"></i>
        Jártál már mindenfelé, néztél már rengeteg ismeretterjesztő filmet, kisujjadban vannak az emberiség minden művészeti és építészeti alakotásai?
        Tedd próbára magad, hogy mennyire ismered őket!</h5>
        <br>
           <h5>Utazz velünk körbe a világon, ugrálj a térben és az időben, és ismerd fel, mit ábrázolnak a képek.
            Játékunk célja hogy szórakoztasson, emlékeket idézzen fel, ötleteket adjon utazásokhoz, és oktasson ezzel a kvízzel a világon található csodákról.
           </h5>
  </div>
  <div class="col-6 mt-5">
    A műveltség a nagy kapcsolatrendszerek ismeretét jelenti. Kapcsolatban állunk anyagi és szellemi környezetünkkel: de a környezetünkhöz 
    tartozik a millió fényévnyi távolságban felrobbant csillag, feleségünk, a közérti eladó és a Halotti beszéd. Helyünk ismerete az 
    Univerzumban, az élők világában, a társadalomban, a családban, felismert helyzetünkből fakadó cselekvésünk: ez mind a műveltséghez tartozik. 
    Röviden a műveltség: általános viszonylatrendszerek (mint történelmi folyamatok) ismerete - annyi konkrét tényanyaggal, amennyivel az 
    általános elveket a valósághoz lehet rögzíteni.
    - Simonyi Károly - 
     <br>
     
  
      <div class="d-flex justify-content-center mt-5 " id="carousel">
           <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="../img/1.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="../img/3.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="../img/2.jpg" class="d-block w-100" alt="...">
      </div>
      </div>
      </div>
  </div>
      
      </div>
      
    </div>
  </div>
   
  </template>
  
  <script>
  export default {
    data() {
      return {
       
      };
    }
  };
  
  </script>
  
  <style scoped>
  #carousel{
    max-width: 70%;
    max-height: 70%; 
  }
  </style>
import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AllCardView from '../views/cards/AllCardView.vue';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
      meta:{
        title: "Home nézet"
      }
    },
    {
    path: '/cards',
    name: 'cards',
    component: AllCardView,
    meta: {
      title: "A kérdések tábla kirendelelve"
    }
  },
    {
      path: '/about',
      name: 'about',
      component: () => import('../views/AboutView.vue'),
      meta:{
        title: "Rólunk"
      }
    },
    {
      path: '/game',
      name: 'game',
      component: ()=> import('@/views/GameView.vue'),
      meta:{
        title: "Játék"
      }
    },    
    {
      path: '/login',
      name: 'login',
      component: ()=> import('@/views/LoginView.vue'),
      meta:{
        title: "Bejelentkezés"
      }
    },
    {
      path: '/register',
      name: 'register',
      component: ()=> import('@/views/RegisterView.vue'),
      meta:{
        title: "Regisztráció"
      }
    },
    {
      path: '/contact',
      name: 'contact',
      component: ()=> import('@/views/ContactView.vue'),
      meta:{
        title: "Kapcsolat"
      }
    },
    {
      path: '/database',
      name: 'database',
      component: () => import('../views/DatabaseListView.vue'),
      meta:{
        title: "A MySQL adatbázis kirenderelve"
      }
    },
    {
      path: "/interestingFacts",
      name: "interestingFacts",
      component: ()=> import('@/views/InterestingFactsView.vue'),
      meta:{
        title: "Töltelék"
      }
  },
  {
    path: '/prizes',
    name: 'prizes',
    component: ()=> import('@/views/PrizesView.vue'),
    meta:{
      title: "A nyertesek és a nyeremény"
    }
  },
  ]
})


router.beforeEach((to,from, next) => { document.title=`${to.meta.title} - VeeApp`;
  next();
})
export default router

interface User {
    id
}
import mysql from 'mysql2'
import dotenv from 'dotenv'
import bcrypt from 'bcrypt'
dotenv.config()

const pool = mysql.createPool({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE
}).promise()

export async function getQuestions() {
    const [rows] = await pool.query("SELECT * FROM questions")
    return rows
}

export async function getQuestion(id) {
    const [rows] = await pool.query(`
    SELECT * FROM questions
    WHERE id = ?`, [id])
    return rows }
    
export async function createQuestion(name, imagePath, answer1, answer2, answer3) {
   const [result] = await pool.query(`
    INSERT INTO questions (name, imagePath, answer1, answer2, answer3)
    VALUES (?, ?, ?, ?, ?)
    `, [name, imagePath, answer1, answer2, answer3])
    const id = result.insertId
    return getQuestion(id)
}

export async function deleteQuestion(id) {
    const [rows] = await pool.query(`
    DELETE FROM questions
    WHERE id = ?`, [id])
    return
   }

export async function updateQuestion(id, name, imagePath, answer1, answer2, answer3) {
    try {
        await pool.query(`
            UPDATE questions
            SET name = ?, imagePath = ?, answer1 = ?, answer2 = ?, answer3 = ?
            WHERE id = ?
        `, [name, imagePath, answer1, answer2, answer3, id]);
        
        // Sikeres frissítés esetén visszaadjuk az új kérdést
        return getQuestion(id);
    } catch (error) {
        console.error('Hiba a kérdés frissítése során:', error);
        throw new Error('Nem sikerült frissíteni a kérdést.');
    }
}

export async function createScore(score, name) {
    const [result] = await pool.query(`
     INSERT INTO scores (score, name)
     VALUES (?, ?)
     `, [score, name])
         return getTopScores()
        }

export async function getScores() {
    const [rows] = await pool.query("SELECT * FROM scores")
    return rows
}
export async function getTopScores() {
    const [rows] = await pool.query("SELECT * FROM scores ORDER BY score DESC LIMIT 10")
    return rows
}

export async function getUsers() {
    const [rows] = await pool.query("SELECT * FROM users")
    return rows
}

export async function getUser(id) {
    const [rows] = await pool.query(`
    SELECT * FROM users
    WHERE id = ?`, [id])
    return rows }

export async function registerUser(name, email, password) {
    // Ellenőrzés, hogy van-e már ilyen email címmel felhasználó az adatbázisban
    const [existingUsers] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (existingUsers.length > 0) {
        // Ha már van ilyen email címmel regisztrált felhasználó, akkor dobok egy hibát, és TODO üzenni
        throw new Error('Ez az email cím már használatban van.');
    }
    // Ha nem találtunk ilyen email címmel regisztrált felhasználót, akkor mehet a regisztráció
    let hashedPassword = await bcrypt.hash(password, 8);
    password = hashedPassword;
    const [result] = await pool.query(`
        INSERT INTO users (name, email, password)
        VALUES (?, ?, ?)
    `, [name, email, password]);

}

export async function loginUser(email, password) {
    // Ellenőrizd, hogy van-e felhasználó az adatbázisban az adott email címmel
    const [existingUsers] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (existingUsers.length === 0) {
        // Ha nem találtál felhasználót ezzel az email címmel, dobj hibát
        throw new Error('Nem található felhasználó ezzel az email címmel.');
    }

    // Ellenőrizd a jelszót
    const user = existingUsers[0];
    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
        // Ha a jelszó nem egyezik, dobj hibát
        throw new Error('Hibás jelszó.');
    }

    return user;
}

/* const loginTry = await loginUser('kalap@abaaadddaba.com', 'blalawwl')
console.log(loginTry) 

 const result = await createUser('Kalapácska', 'kalap@abaaadddaba.com', 'blalawwl')
console.log(result)

*/

/* const loginTry = await loginUser('kalap@abaaadddaba.com', 'blalawwl')
console.log(loginTry) */



/* const result = await getScores()
console.log(result)
const result1 = await getUsers()
console.log(result1) */

/* const result = await createQuestion('aba343', 'abbba', 'blalal', 'reerre434', 'weewe' )
console.log(result) */
/* 

/* const result = await updateQuestion('19','eeeeeeeeee', 'aaaaaaaaa', 'blalal', 'reerre434', 'weewe' )
console.log(result) */


/* const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { promisify } = require("util");

const db = mysql.createConnection({
    host: process.env.HOST,
    user: process.env.DATABASE_USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE
});
login = async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).sendFile(__dirname + "/login.html", {
                message: "Please Provide an email and password"
            })
        }
        db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
            console.log(results);
            if (!results || !await bcrypt.compare(password, results[0].password)) {
                res.status(401).sendFile(__dirname + '/login.html', {
                    message: 'Email or Password is incorrect'
                })
            } else {
                const id = results[0].id;

                const token = jwt.sign({ id }, process.env.JWT_SECRET, {
                    expiresIn: process.env.JWT_EXPIRES_IN
                });

                console.log("the token is " + token);

                const cookieOptions = {
                    expires: new Date(
                        Date.now() + process.env.JWT_COOKIE_EXPIRES * 24 * 60 * 60 * 1000
                    ),
                    httpOnly: true
                }
                res.cookie('userSave', token, cookieOptions);
                res.status(200).redirect("/");
            }
        })
    } catch (err) {
        console.log(err);
    }
}

exports.isLoggedIn = async (req, res, next) => {
    if (req.cookies.userSave) {
        try {
            // 1. Verify the token
            const decoded = await promisify(jwt.verify)(req.cookies.userSave,
                process.env.JWT_SECRET
            );
            console.log(decoded);

            // 2. Check if the user still exist
            db.query('SELECT * FROM users WHERE id = ?', [decoded.id], (err, results) => {
                console.log(results);
                if (!results) {
                    return next();
                }
                req.user = results[0];
                return next();
            });
        } catch (err) {
            console.log(err)
            return next();
        }
    } else {
        next();
    }
}
exports.logout = (req, res) => {
    res.cookie('userSave', 'logout', {
        expires: new Date(Date.now() + 2 * 1000),
        httpOnly: true
    });
    res.status(200).redirect("/");
} */